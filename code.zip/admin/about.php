<?php
require_once('check_login.php');
?>
<?php include"header.php"?>
<!--  Author Name: Mayuri K. 
 for any PHP, Codeignitor or Laravel work contact me at mayuri.infospace@gmail.com  -->
<?php include"sidebar.php"?>
        
        <div class="page-wrapper">
            
            <div class="row page-titles">
                <div class="col-md-5 align-self-center">
                    <h3 class="text-primary">About Author</h3> </div>
                <div class="col-md-7 align-self-center">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="javascript:void(0)">About Author</a></li>
                        <li class="breadcrumb-item active">Dashboard</li>
                    </ol>
                </div>
            </div>
            
            
            <div class="container-fluid">
                
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card card-outline-primary">
                            
                            <div class="card-body">
                               
                                    <div class="form-body">
                                        <h3 class="card-title m-t-15"><strong>Basic Info</strong>   </h3>
                                        <hr>
                      <h4>                  Name:   Mayuri K.
                        <br>
Nationality:    Indian
                        </h4>      <br>
                        <h3 class="card-title m-t-15"><strong>Eduction & Knowledge</strong>   </h3>
                        <hr>
                      <h4>                  Education:  Masters in Computer Science<br>
Programming Language:   PHP, Codeignitor and Laravel
                        </h4>      

                         <br>
                        <h3 class="card-title m-t-15"><strong>Work Experience</strong>   </h3>
                        <hr>
                      <h4>                  Doing Freelancing   from last 4 Years
                        </h4>  
<br><br>
                        <h3 class="card-title m-t-15"><strong>Note :</strong>   </h3>
                        <hr>
                      <h4><strong><mark>For students or anyone else who needs program or source code for thesis writing or<br><br>

any Professional Software Development, Website Development, Mobile Apps Development

<br><br>at affordable cost. Contact me at Email : mayuri.infospace@gmail.com</mark>
</strong>                        </h4>      
                           
                                        

                                       
                                    </div>
                                   
                               
                            </div>
                        </div>
                
 </div>
</div>
</div>
                   
          <!--  Author Name: Mayuri K. 
 for any PHP, Codeignitor or Laravel work contact me at mayuri.infospace@gmail.com  -->
<?php include"footer.php"?>